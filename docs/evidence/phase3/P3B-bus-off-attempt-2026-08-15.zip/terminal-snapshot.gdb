set pagination off
set confirm off
file build/hpm5321-ram-debug-bus-off/output/demo.elf
set $p3b_expected_run_nonce = 0x6A80412F
source scripts/phase3/p3b_bus_off_snapshot.gdb
