set pagination off
set confirm off
file build/hpm5321-ram-debug-bus-off/output/demo.elf
target remote localhost:2331
monitor halt
monitor reset
monitor halt
load
set $pc = _start
printf "P3B_RAM_IMAGE_LOADED\n"
p/x $pc
monitor go
detach
quit
