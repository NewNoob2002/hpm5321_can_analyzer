set pagination off
set confirm off
file build/hpm5321-ram-debug-bus-off/output/demo.elf
target remote localhost:2331
monitor halt
printf "P3B_BUS_OFF_TIMEOUT_DUMP\n"
p g_app_mcan0_bus_off_test_mailbox
p g_app_mcan0_bus_off_test_result
p g_app_mcan0_owner_state
p/x *(unsigned int *)0xF0280018
p/x *(unsigned int *)0xF02800CC
detach
quit
