set pagination off
set confirm off
file build/hpm5321-ram-debug-bus-off/output/demo.elf
set $p3b_run_nonce = 0x6A80412F
source scripts/phase3/p3b_bus_off_arm.gdb
printf "P3B_BUS_OFF_ARMED nonce=0x6A80412F\n"
p g_app_mcan0_bus_off_test_mailbox
monitor go
detach
quit
